import os

print "hello  world"